import { createHash } from "node:crypto";

export type CuratedPolicySource = {
  sourceIdentifier: string;
  billNumber: string;
  title: string;
  sessionYear: string;
  recordType: "State law" | "Agency guidance";
  category: string;
  department: string;
  legislativeStatus: string;
  sourceUrl: string;
  sourceText: string;
  impact: string;
  enactedDate?: string;
  effectiveDate?: string;
  lastAmendedDate?: string;
};

// These records are intentionally limited to official California Legislature and
// HCD pages. The excerpts are short source notes; refreshes replace them with
// the latest text fetched from the official page.
export const POLICY_SOURCES: CuratedPolicySource[] = [
  {
    sourceIdentifier: "CA-SB-79-2025",
    billNumber: "SB 79",
    title: "Housing development: transit-oriented development",
    sessionYear: "2025-2026",
    recordType: "State law",
    category: "Transit-Oriented Development",
    department: "Planning",
    legislativeStatus: "Enacted",
    sourceUrl: "https://www.hcd.ca.gov/planning-and-research/sb79-tod",
    sourceText:
      "California HCD identifies SB 79 as a law making qualifying transit-oriented housing developments an allowed use on qualifying residential, mixed-use, or commercial sites near specified transit stops in urban transit counties. SB 79 was signed on October 10, 2025, is codified in Government Code Sections 65912.155-65912.162, and takes effect July 1, 2026. HCD oversees local ordinance and TOD alternative-plan compliance.",
    impact:
      "Planning should map qualifying transit stops and zones, review local zoning and housing-element workflows, and prepare to process qualifying SB 79 housing projects beginning July 1, 2026.",
    enactedDate: "2025-10-10",
    effectiveDate: "2026-07-01",
    lastAmendedDate: "2025-10-10",
  },
  {
    sourceIdentifier: "CA-AB-130-2025",
    billNumber: "AB 130",
    title: "Housing: 2025 budget trailer bill",
    sessionYear: "2025-2026",
    recordType: "State law",
    category: "Housing Administration",
    department: "Planning",
    legislativeStatus: "Enacted",
    sourceUrl:
      "https://leginfo.legislature.ca.gov/faces/billStatusClient.xhtml?bill_id=202520260AB130",
    sourceText:
      "Official California Legislature and LegiScan records identify AB 130 as a housing budget trailer bill. Chapter 22, Statutes of 2025, was approved by the Governor and chaptered on June 30, 2025. The measure makes broad amendments affecting housing approvals, planning and zoning, housing programs, building standards, environmental review, and related state administration, and takes effect immediately.",
    impact:
      "Planning, Building & Safety, and Housing staff should inventory local procedures affected by AB 130, compare current forms and timelines with the amended statutes, and document implementation decisions for staff review.",
    enactedDate: "2025-06-30",
    effectiveDate: "2025-06-30",
    lastAmendedDate: "2025-06-30",
  },
  {
    sourceIdentifier: "CA-AB-976-2023",
    billNumber: "AB 976",
    title: "Accessory dwelling units: owner-occupancy requirements",
    sessionYear: "2023-2024",
    recordType: "State law",
    category: "ADUs",
    department: "Building & Safety",
    legislativeStatus: "Enacted",
    sourceUrl:
      "https://leginfo.legislature.ca.gov/faces/billStatusClient.xhtml?bill_id=202320240AB976",
    sourceText:
      "Official California Legislature bill-status record: AB-976 concerns accessory dwelling unit owner-occupancy requirements. The measure amends Government Code Section 65852.2 and was chaptered as Chapter 751, Statutes of 2023. The source record identifies the measure as non-urgency; this application does not infer an effective date from that label.",
    impact:
      "Planning and Building & Safety should review local ADU application, ordinance, and owner-occupancy materials against the current statute.",
    enactedDate: "2023-10-11",
    lastAmendedDate: "2023-08-28",
  },
  {
    sourceIdentifier: "CA-AB-1033-2023",
    billNumber: "AB 1033",
    title: "Accessory dwelling units: separate sale or conveyance",
    sessionYear: "2023-2024",
    recordType: "State law",
    category: "ADUs",
    department: "Building & Safety",
    legislativeStatus: "Enacted",
    sourceUrl:
      "https://leginfo.legislature.ca.gov/faces/billStatusClient.xhtml?bill_id=202320240AB1033",
    sourceText:
      "Official California Legislature bill-status record: AB-1033 concerns local ordinances and separate sale or conveyance of accessory dwelling units. The measure amends Government Code Sections 65852.2 and 65852.26 and was chaptered as Chapter 752, Statutes of 2023. The source record does not by itself establish a City-specific implementation decision.",
    impact:
      "The City should review whether its ADU ordinance and real-property procedures address the state law's separate-sale framework.",
    enactedDate: "2023-10-11",
    lastAmendedDate: "2023-08-24",
  },
  {
    sourceIdentifier: "CA-SB-423-2023",
    billNumber: "SB 423",
    title: "Streamlined housing approvals for multifamily housing developments",
    sessionYear: "2023-2024",
    recordType: "State law",
    category: "Permitting",
    department: "Planning",
    legislativeStatus: "Enacted",
    sourceUrl:
      "https://leginfo.legislature.ca.gov/faces/billStatusClient.xhtml?bill_id=202320240SB423",
    sourceText:
      "Official California Legislature bill-status record: SB-423 concerns streamlined housing approvals for multifamily housing developments. The measure amends Government Code Section 65913.4 and was chaptered as Chapter 778, Statutes of 2023. The application preserves the source status while leaving legal interpretation to staff review.",
    impact:
      "Planning should review ministerial approval procedures, objective standards, and the records used to evaluate qualifying multifamily projects.",
    enactedDate: "2023-10-11",
    lastAmendedDate: "2023-09-01",
  },
  {
    sourceIdentifier: "CA-AB-2011-2022",
    billNumber: "AB 2011",
    title: "Affordable Housing and High Road Jobs Act of 2022",
    sessionYear: "2021-2022",
    recordType: "State law",
    category: "Affordable Housing",
    department: "Planning",
    legislativeStatus: "Enacted",
    sourceUrl:
      "https://leginfo.legislature.ca.gov/faces/billStatusClient.xhtml?bill_id=202120220AB2011",
    sourceText:
      "Official California Legislature bill-status record: AB-2011 is the Affordable Housing and High Road Jobs Act of 2022. The measure adds and repeals Government Code Chapter 4.1 beginning with Section 65912.100 and was chaptered as Chapter 647, Statutes of 2022. Local implementation details require review of the current statute and regulations.",
    impact:
      "Planning and Economic & Community Development should review qualifying sites, affordability requirements, and labor or permitting workflows before relying on this law.",
    enactedDate: "2022-09-28",
    lastAmendedDate: "2022-08-25",
  },
  {
    sourceIdentifier: "CA-AB-1893-2024",
    billNumber: "AB 1893",
    title: "Housing Accountability Act: required local findings",
    sessionYear: "2023-2024",
    recordType: "State law",
    category: "Housing Accountability",
    department: "Planning",
    legislativeStatus: "Enacted",
    sourceUrl:
      "https://leginfo.legislature.ca.gov/faces/billStatusClient.xhtml?bill_id=202320240AB1893",
    sourceText:
      "Official California Legislature bill-status record: AB-1893 concerns Housing Accountability Act housing disapprovals and required local findings. The measure amends Government Code Section 65589.5 and was chaptered as Chapter 268, Statutes of 2024. The record is a source reference, not a legal compliance determination.",
    impact:
      "Planning and City Attorney staff should review objective-standard findings and denial documentation used for housing development applications.",
    enactedDate: "2024-09-19",
    lastAmendedDate: "2024-08-23",
  },
  {
    sourceIdentifier: "CA-SB-35-2017",
    billNumber: "SB 35",
    title: "Affordable housing streamlined approval process",
    sessionYear: "2017-2018",
    recordType: "State law",
    category: "Affordable Housing",
    department: "Planning",
    legislativeStatus: "Enacted",
    sourceUrl:
      "https://leginfo.legislature.ca.gov/faces/billStatusClient.xhtml?bill_id=201720180SB35",
    sourceText:
      "Official California Legislature bill-status record: SB-35 concerns planning and zoning for affordable housing and a streamlined approval process. The measure added and repealed Government Code Section 65913.4 and was chaptered as Chapter 366, Statutes of 2017. Current applicability should be checked against later amendments.",
    impact:
      "Planning should keep the City's streamlined approval procedures and eligibility documentation aligned with the current version of the law.",
    enactedDate: "2017-09-29",
    lastAmendedDate: "2017-09-01",
  },
  {
    sourceIdentifier: "CA-HCD-DENSITY-BONUS-2026",
    billNumber: "Gov. Code §§ 65914.1, 65915-65915.5",
    title: "State Density Bonus Law",
    sessionYear: "2026 guidance",
    recordType: "Agency guidance",
    category: "Density Bonus",
    department: "Planning",
    legislativeStatus: "Effective",
    sourceUrl: "https://www.hcd.ca.gov/hau/enforcement-authority",
    sourceText:
      "California HCD's Housing Accountability Unit identifies the State Density Bonus Law as Government Code Sections 65915-65918. HCD explains that qualifying affordable housing projects may receive increased density, incentives, concessions, and waivers or reductions of development standards, including parking requirements, subject to statutory conditions.",
    impact:
      "Planning should review density-bonus calculations, incentives, concessions, waivers, and parking analysis for qualifying projects.",
  },
  {
    sourceIdentifier: "CA-HCD-ADU-LAW-2026",
    billNumber: "Gov. Code §§ 66310-66342",
    title: "Accessory Dwelling Unit Law",
    sessionYear: "2026 guidance",
    recordType: "Agency guidance",
    category: "ADUs",
    department: "Building & Safety",
    legislativeStatus: "Effective",
    sourceUrl: "https://www.hcd.ca.gov/hau/enforcement-authority",
    sourceText:
      "California HCD's Housing Accountability Unit identifies the Accessory Dwelling Unit Law as Government Code Sections 66310 through 66342. HCD describes ADUs and junior ADUs as a flexible form of housing and explains that the law addresses barriers, streamlines approval, and expands potential capacity.",
    impact:
      "Building & Safety and Planning should compare local ADU application, ordinance, and approval procedures with the current state-law requirements.",
  },
];

export function policyHash(value: string) {
  return createHash("sha256").update(value).digest("hex");
}

function dateValue(value?: string) {
  return value ? new Date(`${value}T12:00:00.000Z`) : null;
}

export function policySeedData(source: CuratedPolicySource, now = new Date()) {
  return {
    title: source.title,
    billNumber: source.billNumber,
    sourceIdentifier: source.sourceIdentifier,
    sessionYear: source.sessionYear,
    recordType: source.recordType,
    category: source.category,
    department: source.department,
    legislativeStatus: source.legislativeStatus,
    relevance: "Needs Review",
    impact: source.impact,
    introducedDate: null,
    publishedDate: null,
    enactedDate: dateValue(source.enactedDate),
    lastAmendedDate: dateValue(source.lastAmendedDate),
    effectiveDate: dateValue(source.effectiveDate),
    deadline: null,
    sourceUrl: source.sourceUrl,
    sourceText: source.sourceText,
    sourceStatus: "Source checked",
    sourceHash: policyHash(source.sourceText),
    lastCheckedAt: now,
    updateState: "New",
    lastChangeSummary: "Imported from an authoritative California government source.",
    sample: false,
    verification: "Needs Verification",
    implementationStatus: "Not Reviewed",
    reviewNote:
      "Source checked against an official California government page. Human legal and City-process review is still required.",
  };
}
