import { db } from "./db";
import { audit } from "./api";
import {
  POLICY_SOURCES,
  policyHash,
  policySeedData,
  type CuratedPolicySource,
} from "./policy-sources";

const MAX_SOURCE_TEXT = 200_000;

export type PolicyRefreshResult = {
  sourceIdentifier: string;
  billNumber: string;
  title: string;
  outcome: "imported" | "updated" | "unchanged" | "error";
  message: string;
};

function htmlText(value: string) {
  return value
    .replace(/<script[\s\S]*?<\/script>/gi, " ")
    .replace(/<style[\s\S]*?<\/style>/gi, " ")
    .replace(/<[^>]+>/g, " ")
    .replace(/&nbsp;/gi, " ")
    .replace(/&amp;/gi, "&")
    .replace(/&quot;/gi, '"')
    .replace(/&#39;/gi, "'")
    .replace(/\s+/g, " ")
    .trim();
}

function sourceStatus(source: CuratedPolicySource, text: string) {
  if (source.recordType !== "State law") return source.legislativeStatus;
  if (/Chaptered|Approved by the Governor/i.test(text)) return "Enacted";
  if (/Active Bill|Pending Referral|In Committee/i.test(text)) return "Proposed";
  return "Needs Verification";
}

async function fetchSource(source: CuratedPolicySource) {
  const response = await fetch(source.sourceUrl, {
    headers: { Accept: "text/html", "User-Agent": "Bakersfield-Housing-Policy-Navigator/1.0" },
    signal: AbortSignal.timeout(15_000),
  });
  if (!response.ok) throw new Error(`Official source returned HTTP ${response.status}.`);
  const contentType = response.headers.get("content-type") || "";
  if (!contentType.includes("text/html") && !contentType.includes("text/plain"))
    throw new Error("The official source is not an HTML/text page; use the manual import workflow for this source.");
  const text = htmlText(await response.text());
  if (text.length < 80) throw new Error("The official source returned too little readable text.");
  return text.slice(0, MAX_SOURCE_TEXT);
}

function changedFields(before: Record<string, unknown>, after: Record<string, unknown>) {
  return [
    "title",
    "billNumber",
    "legislativeStatus",
    "sourceText",
    "sourceUrl",
    "lastAmendedDate",
  ].filter((field) => String(before[field] ?? "") !== String(after[field] ?? ""));
}

export async function refreshOfficialPolicies(actor: string) {
  const checkedAt = new Date();
  const results: PolicyRefreshResult[] = [];
  for (const source of POLICY_SOURCES) {
    try {
      const fetchedText = await fetchSource(source);
      const hash = policyHash(fetchedText);
      const status = sourceStatus(source, fetchedText);
      const existing = await db.policy.findFirst({
        where: { sourceIdentifier: source.sourceIdentifier },
      });
      if (!existing) {
        const created = await db.$transaction(async (tx) => {
          const seed = policySeedData(source, checkedAt);
          const policy = await tx.policy.create({
            data: {
              ...seed,
              sourceText: fetchedText,
              sourceHash: hash,
              legislativeStatus: status,
              lastChangeSummary: "Imported from the official source during refresh.",
            },
          });
          await tx.policyUpdate.create({
            data: {
              policyId: policy.id,
              eventType: "New",
              summary: "New policy imported from an official California government source.",
              changedFields: "record",
              sourceUrl: source.sourceUrl,
              sourceHash: hash,
              afterJson: JSON.stringify({ sourceIdentifier: source.sourceIdentifier, status }),
            },
          });
          await audit(tx, {
            actor,
            action: "Policy imported from official source",
            entityType: "Policy",
            entityId: policy.id,
            detail: `${source.billNumber} was imported from ${source.sourceUrl}. Human review remains required.`,
            after: policy,
          });
          return policy;
        });
        results.push({ sourceIdentifier: source.sourceIdentifier, billNumber: source.billNumber, title: created.title, outcome: "imported", message: "Imported and marked for human review." });
        continue;
      }
      const beforeSnapshot = {
        title: existing.title,
        billNumber: existing.billNumber,
        legislativeStatus: existing.legislativeStatus,
        sourceText: existing.sourceText,
        sourceUrl: existing.sourceUrl,
        lastAmendedDate: existing.lastAmendedDate,
      };
      const afterSnapshot = {
        ...beforeSnapshot,
        title: source.title,
        billNumber: source.billNumber,
        legislativeStatus: status,
        sourceText: fetchedText,
        sourceUrl: source.sourceUrl,
        lastAmendedDate: source.lastAmendedDate
          ? new Date(`${source.lastAmendedDate}T12:00:00.000Z`)
          : null,
      };
      const fields = changedFields(beforeSnapshot, afterSnapshot);
      const sourceChanged = existing.sourceHash !== hash;
      const changed = sourceChanged || fields.length > 0;
      await db.$transaction(async (tx) => {
        const policy = await tx.policy.update({
          where: { id: existing.id },
          data: {
            title: source.title,
            billNumber: source.billNumber,
            sessionYear: source.sessionYear,
            recordType: source.recordType,
            category: source.category,
            department: source.department,
            legislativeStatus: status,
            sourceUrl: source.sourceUrl,
            ...(changed ? { sourceText: fetchedText, sourceHash: hash } : {}),
            sourceStatus: "Source checked",
            lastCheckedAt: checkedAt,
            updateState: changed ? "Updated" : existing.updateState,
            lastChangeSummary: changed
              ? "The official source content or metadata changed since the previous check."
              : "No source change detected on the latest official-source check.",
          },
        });
        if (changed) {
          await tx.policyUpdate.create({
            data: {
              policyId: policy.id,
              eventType: "Updated",
              summary: "The official source content or metadata changed.",
              changedFields: [...fields, ...(sourceChanged ? ["sourceHash"] : [])].join(", "),
              sourceUrl: source.sourceUrl,
              sourceHash: hash,
              beforeJson: JSON.stringify(beforeSnapshot),
              afterJson: JSON.stringify(afterSnapshot),
            },
          });
          await audit(tx, {
            actor,
            action: "Official policy source updated",
            entityType: "Policy",
            entityId: policy.id,
            detail: `${source.billNumber} changed during an official-source refresh. Staff review is required.`,
            before: beforeSnapshot,
            after: afterSnapshot,
          });
        }
      });
      results.push({ sourceIdentifier: source.sourceIdentifier, billNumber: source.billNumber, title: source.title, outcome: changed ? "updated" : "unchanged", message: changed ? "Source changed; record marked Updated and Needs Review." : "No source change detected." });
    } catch (error) {
      const message = error instanceof Error ? error.message : "The official source could not be checked.";
      const existing = await db.policy.findFirst({ where: { sourceIdentifier: source.sourceIdentifier } });
      if (existing) {
        await db.$transaction(async (tx) => {
          await tx.policy.update({
            where: { id: existing.id },
            data: {
              sourceStatus: "Needs Verification",
              lastCheckedAt: checkedAt,
              updateState: "Needs Review",
              lastChangeSummary: `Official source unavailable: ${message}`,
            },
          });
          await tx.policyUpdate.create({
            data: {
              policyId: existing.id,
              eventType: "Needs Review",
              summary: `Official source unavailable during refresh: ${message}`,
              changedFields: "sourceStatus",
              sourceUrl: source.sourceUrl,
              sourceHash: existing.sourceHash,
            },
          });
        });
      }
      results.push({ sourceIdentifier: source.sourceIdentifier, billNumber: source.billNumber, title: source.title, outcome: "error", message });
    }
  }
  return {
    checkedAt: checkedAt.toISOString(),
    imported: results.filter((r) => r.outcome === "imported").length,
    updated: results.filter((r) => r.outcome === "updated").length,
    unchanged: results.filter((r) => r.outcome === "unchanged").length,
    errors: results.filter((r) => r.outcome === "error").length,
    results,
  };
}
