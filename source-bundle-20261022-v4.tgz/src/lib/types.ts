export type Role = "ADMIN" | "STAFF" | "REVIEWER";
export type User = {
  id: string;
  name: string;
  email: string;
  role: Role;
  department: string;
  active: boolean;
};
export type Claim = {
  text: string;
  quote: string;
  sourceId: string;
  verification: "Needs Verification" | "Source supported" | "Staff verified";
};
export type AnalysisResult = {
  mode: "demo" | "live";
  summary: Claim[];
  changes: Claim[];
  plainEnglish: Claim[];
  impacts: Claim[];
  actions: Claim[];
  dates: Claim[];
  questions: string[];
  warnings: string[];
};
export type Policy = {
  id: string;
  title: string;
  billNumber: string;
  sourceIdentifier: string;
  sessionYear: string;
  recordType: string;
  category: string;
  legislativeStatus: string;
  relevance: string;
  impact: string;
  introducedDate: string | null;
  publishedDate: string | null;
  enactedDate: string | null;
  lastAmendedDate: string | null;
  effectiveDate: string | null;
  deadline: string | null;
  sourceUrl: string;
  sourceText: string;
  sourceStatus: string;
  sourceHash: string;
  lastCheckedAt: string | null;
  updateState: string;
  lastChangeSummary: string;
  sample: boolean;
  verification: string;
  implementationStatus: string;
  department: string;
  analysis: AnalysisResult | null;
  analysisHistory: PolicyAnalysis[];
  lastVerifiedAt: string | null;
  createdAt: string;
  updatedAt: string;
  reviewNote: string;
};
export type PolicyAnalysis = {
  id: string;
  policyId: string;
  mode: "demo" | "live";
  model: string;
  sourceHash: string;
  createdById: string;
  createdBy: string;
  createdAt: string;
};
export type PolicyUpdate = {
  id: string;
  policyId: string | null;
  eventType: string;
  summary: string;
  changedFields: string;
  sourceUrl: string;
  sourceHash: string;
  detectedAt: string;
};
export type Task = {
  id: string;
  title: string;
  description: string;
  department: string;
  assignee: string;
  dueDate: string | null;
  dateType:
    | "Staff target"
    | "Verified statutory"
    | "AI suggested"
    | "Needs Verification";
  priority: "Low" | "Medium" | "High" | "Urgent";
  status: "To do" | "In progress" | "Blocked" | "Completed" | "Done";
  notes: string;
  checklist: { text: string; done: boolean }[];
  comments: { author: string; text: string; createdAt: string }[];
  createdById: string;
  policyId: string | null;
  actionPlanId: string | null;
  actionPlanItemId: string;
  supportingDocumentId: string | null;
  sourceQuote: string;
  createdAt: string;
  updatedAt: string;
};
export type ActionPlanItem = {
  id: string;
  title: string;
  rationale: string;
  department: string;
  assignee: string;
  urgency: "Low" | "Normal" | "High" | "Urgent";
  dueDate: string | null;
  monitor: boolean;
  sourceQuote: string;
};
export type ActionPlan = {
  id: string;
  policyId: string;
  title: string;
  summary: string;
  status: "Draft" | "Approved" | "Converted";
  noImmediateAction: boolean;
  items: ActionPlanItem[];
  createdById: string;
  createdBy: string;
  approvedBy: string;
  approvedAt: string | null;
  createdAt: string;
  updatedAt: string;
};
export type Document = {
  id: string;
  name: string;
  kind: string;
  text: string;
  createdAt: string;
};
export type Audit = {
  id: string;
  actor: string;
  action: string;
  entityType: string;
  entityId: string;
  detail: string;
  createdAt: string;
};
export type ComparisonResult = {
  id?: string;
  kind: "gap" | "change";
  mode: "demo" | "live";
  findings: {
    type: "Possible gap" | "Documented difference" | "Needs Review";
    title: string;
    detail: string;
    policyQuote: string;
    comparisonQuote: string;
    recommendation: string;
  }[];
  missingDocuments: string[];
  disclaimer: string;
};
export type Workspace = {
  user: User;
  mode: "demo" | "live";
  policies: Policy[];
  tasks: Task[];
  documents: Document[];
  audit: Audit[];
  policyUpdates: PolicyUpdate[];
  actionPlans: ActionPlan[];
  users: User[];
};
export const CATEGORIES = [
  "Permitting",
  "ADUs",
  "Zoning",
  "Funding",
  "Housing Element",
  "Affordable Housing",
  "Density Bonus",
  "Housing Accountability",
  "Parking",
  "Administration",
];
export const DEPARTMENTS = [
  "Planning",
  "Building & Safety",
  "Economic & Community Development",
  "City Attorney",
  "City Manager",
];
export const STAGES = [
  "Not Reviewed",
  "Under Review",
  "Action Required",
  "Completed",
];
export const TASK_STATUSES = ["To do", "In progress", "Blocked", "Completed"] as const;
export const TASK_PRIORITIES = ["Low", "Medium", "High", "Urgent"] as const;
export const STATUSES = [
  "Needs Verification",
  "Proposed",
  "Passed",
  "Enacted",
  "Effective",
];
