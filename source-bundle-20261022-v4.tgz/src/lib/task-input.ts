import type { Task, Prisma } from "@prisma/client";
import { db } from "./db";
import {
  ApiError,
  dateValue,
  enumValue,
  isOfficialSource,
  sourceSupportsDate,
  stringValue,
} from "./api";
import { requireReviewer } from "./auth";
import {
  DEPARTMENTS,
  TASK_PRIORITIES,
  TASK_STATUSES,
  type User,
} from "./types";

function parseList(value: string | undefined) {
  try {
    const parsed = JSON.parse(value || "[]");
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

function checklistValue(value: unknown, before?: Task) {
  if (value === undefined) return parseList(before?.checklistJson);
  if (!Array.isArray(value) || value.length > 30)
    throw new ApiError(400, "Checklist must contain at most 30 items.");
  return value.map((item) => {
    if (!item || typeof item !== "object" || Array.isArray(item))
      throw new ApiError(400, "Checklist contains an invalid item.");
    const row = item as Record<string, unknown>;
    return {
      text: stringValue(row.text, "Checklist item", 500, true),
      done: row.done === true,
    };
  });
}

export async function taskInput(
  body: Record<string, unknown>,
  user: User,
  before?: Task,
) {
  const rawStatus = enumValue(
    body.status ?? before?.status ?? "To do",
    [...TASK_STATUSES, "Done"],
    "task status",
  );
  const policyId =
    "policyId" in body
      ? body.policyId === "" || body.policyId === null
        ? null
        : stringValue(body.policyId, "Related policy", 100)
      : before?.policyId || null;
  const data = {
    title: stringValue(body.title ?? before?.title, "Task title", 240, true),
    description: stringValue(
      body.description ?? before?.description ?? "",
      "Description",
      10_000,
    ),
    department: enumValue(
      body.department ?? before?.department ?? "Planning",
      DEPARTMENTS,
      "department",
    ),
    assignee: stringValue(
      body.assignee ?? before?.assignee ?? "",
      "Assignee",
      240,
    ),
    dueDate:
      "dueDate" in body
        ? dateValue(body.dueDate, "Due date")
        : (before?.dueDate ?? null),
    dateType: enumValue(
      body.dateType ?? before?.dateType ?? "Staff target",
      [
        "Staff target",
        "Verified statutory",
        "AI suggested",
        "Needs Verification",
      ],
      "date type",
    ),
    priority: enumValue(
      body.priority ?? before?.priority ?? "Medium",
      TASK_PRIORITIES,
      "priority",
    ),
    status: rawStatus === "Done" ? "Completed" : rawStatus,
    notes: stringValue(body.notes ?? before?.notes ?? "", "Notes", 20_000),
    checklistJson: JSON.stringify(checklistValue(body.checklist, before)),
    commentsJson: before?.commentsJson || "[]",
    createdById: before?.createdById || user.id,
    policyId,
    actionPlanId: before?.actionPlanId ?? null,
    actionPlanItemId: before?.actionPlanItemId ?? "",
    supportingDocumentId:
      ("supportingDocumentId" in body
        ? body.supportingDocumentId
        : before?.supportingDocumentId) || null,
    sourceQuote: stringValue(
      body.sourceQuote ?? before?.sourceQuote ?? "",
      "Source quote",
      10_000,
    ),
  };
  const policy = data.policyId
    ? await db.policy.findUnique({ where: { id: data.policyId } })
    : null;
  if (data.policyId && !policy)
    throw new ApiError(400, "Choose an existing related policy.");
  if (data.supportingDocumentId) {
    data.supportingDocumentId = stringValue(
      data.supportingDocumentId,
      "Supporting document",
      100,
    );
    if (
      !(await db.document.findUnique({
        where: { id: data.supportingDocumentId as string },
      }))
    )
      throw new ApiError(400, "Supporting document not found.");
  }
  if (data.dateType === "Verified statutory") {
    if (!policy) throw new ApiError(400, "A statutory date must be linked to a policy.");
    const dateChanged =
      !before ||
      before.dateType !== "Verified statutory" ||
      before.dueDate?.getTime() !== data.dueDate?.getTime() ||
      before.sourceQuote !== data.sourceQuote ||
      before.policyId !== data.policyId;
    if (dateChanged) requireReviewer(user);
    if (
      policy.sample ||
      policy.verification !== "Verified" ||
      !isOfficialSource(policy.sourceUrl)
    )
      throw new ApiError(
        400,
        "A statutory deadline requires a human-verified policy and an official source.",
      );
    if (
      !data.dueDate ||
      !data.sourceQuote ||
      !policy.sourceText.includes(data.sourceQuote) ||
      !sourceSupportsDate(data.sourceQuote, data.dueDate)
    )
      throw new ApiError(
        400,
        "A verified statutory date needs an exact source quotation that contains the due date.",
      );
  }
  if ("comment" in body && body.comment) {
    const comment = stringValue(body.comment, "Comment", 2_000, true);
    const comments = parseList(before?.commentsJson);
    data.commentsJson = JSON.stringify([
      ...comments.slice(-49),
      { author: user.name, text: comment, createdAt: new Date().toISOString() },
    ]);
  }
  return data as Prisma.TaskUncheckedCreateInput;
}
