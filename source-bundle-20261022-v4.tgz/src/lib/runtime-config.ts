import { ApiError } from "./api";

export function hasPersistentDatabase() {
  const url = process.env.DATABASE_URL || "";
  return url.startsWith("postgres://") || url.startsWith("postgresql://");
}

export function assertOperationalStorage() {
  if (process.env.DEMO_MODE !== "true" && !hasPersistentDatabase()) {
    throw new ApiError(
      503,
      "Persistent production storage is not configured. Use PostgreSQL with DEMO_MODE=false before storing City information.",
    );
  }
  if (process.env.DEMO_MODE !== "true") {
    const appUrl = process.env.APP_URL || "";
    if (!appUrl.startsWith("https://"))
      throw new ApiError(503, "Production employee access requires an HTTPS APP_URL.");
  }
}

export function publicRuntimeConfig() {
  const demo = process.env.DEMO_MODE === "true";
  const liveConfigured = process.env.AI_MODE === "live" && Boolean(process.env.OPENAI_API_KEY);
  return {
    demoMode: demo,
    sharedDemo: demo && process.env.NEXT_PUBLIC_SHARED_DEMO === "true",
    storage: demo ? "temporary-demo" : hasPersistentDatabase() ? "persistent-database" : "unconfigured",
    persistentStorage: hasPersistentDatabase(),
    aiMode: process.env.AI_MODE === "live" ? "live" : "demo",
    aiConfigured: liveConfigured,
  } as const;
}
