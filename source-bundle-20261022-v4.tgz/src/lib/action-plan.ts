import { randomUUID } from "node:crypto";
import type { ActionPlanItem, Policy, User } from "./types";
import { ApiError, dateValue, enumValue, stringValue } from "./api";
import { DEPARTMENTS } from "./types";

export const URGENCY = ["Low", "Normal", "High", "Urgent"] as const;
type PolicySource = Pick<Policy, "title" | "department" | "sourceText" | "analysis">;

export function parseItems(value: string | null | undefined): ActionPlanItem[] {
  try {
    const parsed = JSON.parse(value || "[]");
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

export function planJSON(row: { itemsJson: string; [key: string]: unknown }) {
  const { itemsJson, ...rest } = row;
  return { ...rest, items: parseItems(itemsJson), noImmediateAction: rest.noImmediateAction === true };
}

export function generatedItems(policy: PolicySource): ActionPlanItem[] {
  const claims = policy.analysis?.actions?.length
    ? policy.analysis.actions
    : policy.analysis?.impacts?.length
      ? policy.analysis.impacts
      : [];
  if (!claims.length)
    return [
      {
        id: randomUUID(),
        title: "Review the official source and identify local implications",
        rationale:
          "No source-grounded action claim was available. Staff should review the complete source before deciding whether the City needs to act.",
        department: policy.department,
        assignee: "",
        urgency: "Normal",
        dueDate: null,
        monitor: true,
        sourceQuote: "",
      },
    ];
  return claims.slice(0, 8).map((claim, index) => ({
    id: randomUUID(),
    title: claim.text.slice(0, 240),
    rationale:
      "Suggested review step based on the policy analysis. It is not a legal requirement until an authorized reviewer confirms it.",
    department: policy.department,
    assignee: "",
    urgency: index === 0 ? "High" : "Normal",
    dueDate: null,
    monitor: true,
    sourceQuote: claim.quote,
  }));
}

export function parseAndValidateItems(value: unknown, policy: PolicySource, allowEmpty = false): ActionPlanItem[] {
  if (!Array.isArray(value) || value.length > 12 || (!allowEmpty && value.length < 1))
    throw new ApiError(400, allowEmpty ? "Add at most 12 action-plan items." : "Add between 1 and 12 action-plan items.");
  return value.map((item, index) => {
    if (!item || typeof item !== "object" || Array.isArray(item))
      throw new ApiError(400, `Action item ${index + 1} is invalid.`);
    const row = item as Record<string, unknown>;
    const sourceQuote = stringValue(row.sourceQuote ?? "", "Source quote", 10_000);
    if (sourceQuote && !policy.sourceText.includes(sourceQuote))
      throw new ApiError(400, `Action item ${index + 1} includes a quote that is not present in the policy source.`);
    return {
      id: stringValue(row.id ?? randomUUID(), "Action item ID", 100, true),
      title: stringValue(row.title, "Action title", 240, true),
      rationale: stringValue(row.rationale, "Action rationale", 2_000, true),
      department: enumValue(row.department ?? policy.department, DEPARTMENTS, "action department"),
      assignee: stringValue(row.assignee ?? "", "Action assignee", 240),
      urgency: enumValue(row.urgency ?? "Normal", URGENCY, "urgency") as ActionPlanItem["urgency"],
      dueDate: dateValue(row.dueDate ?? null, "Action due date")?.toISOString() || null,
      monitor: row.monitor !== false,
      sourceQuote,
    };
  });
}

export function actionPlanData(
  body: Record<string, unknown>,
  policy: PolicySource,
  user: User,
) {
  const noImmediateAction = body.noImmediateAction === true;
  const items = noImmediateAction
    ? []
    : body.items === undefined
      ? generatedItems(policy)
      : parseAndValidateItems(body.items, policy);
  return {
    title: stringValue(body.title ?? `Recommended Action Plan: ${policy.title}`, "Action-plan title", 240, true),
    summary: stringValue(body.summary ?? "Suggested review steps for staff coordination. Recommendations require staff review and approval before becoming assignments.", "Action-plan summary", 4_000),
    noImmediateAction,
    itemsJson: JSON.stringify(items),
    createdById: user.id,
    createdBy: user.name,
  };
}
