import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import {
  ApiError,
  apiError,
  audit,
  readJson,
  requireSameOrigin,
} from "@/lib/api";
import { requireUser } from "@/lib/auth";
import { taskInput } from "@/lib/task-input";

export const runtime = "nodejs";
export async function PATCH(
  request: Request,
  context: { params: Promise<{ id: string }> },
) {
  try {
    requireSameOrigin(request);
    const user = await requireUser(request);
    const { id } = await context.params;
    const before = await db.task.findUnique({ where: { id } });
    if (!before) throw new ApiError(404, "Task not found.");
    const body = await readJson(request, 100_000);
    const progressOnly = Object.keys(body).every((key) =>
      ["status", "notes", "comment", "checklist"].includes(key),
    );
    const canManage =
      user.role !== "STAFF" ||
      before.createdById === user.id ||
      before.assignee.trim().toLowerCase() === user.name.trim().toLowerCase() ||
      (before.assignee.trim() === "" && progressOnly);
    if (!canManage)
      throw new ApiError(
        403,
        "Staff may update only tasks they created or tasks assigned to them.",
      );
    const data = await taskInput(body, user, before);
    const task = await db.$transaction(async (tx) => {
      const updated = await tx.task.update({ where: { id }, data });
      await audit(tx, {
        actor: user.name,
        action: "Implementation task updated",
        entityType: "Task",
        entityId: id,
        detail: `Status: ${updated.status}. Date classification: ${updated.dateType}.`,
        before,
        after: updated,
      });
      return updated;
    });
    return NextResponse.json({ task });
  } catch (error) {
    return apiError(error);
  }
}

export async function DELETE(
  request: Request,
  context: { params: Promise<{ id: string }> },
) {
  try {
    requireSameOrigin(request);
    const user = await requireUser(request);
    const { id } = await context.params;
    const before = await db.task.findUnique({ where: { id } });
    if (!before) throw new ApiError(404, "Task not found.");
    const canDelete =
      user.role !== "STAFF" ||
      before.createdById === user.id ||
      before.assignee.trim().toLowerCase() === user.name.trim().toLowerCase();
    if (!canDelete)
      throw new ApiError(
        403,
        "Staff may delete only tasks they created or tasks assigned to them.",
      );
    await db.$transaction(async (tx) => {
      await tx.task.delete({ where: { id } });
      await audit(tx, {
        actor: user.name,
        action: "Implementation task deleted",
        entityType: "Task",
        entityId: id,
        detail: before.title,
        before,
      });
    });
    return NextResponse.json({ ok: true });
  } catch (error) {
    return apiError(error);
  }
}
