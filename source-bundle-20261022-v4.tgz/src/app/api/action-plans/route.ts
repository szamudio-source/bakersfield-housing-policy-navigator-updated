import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { apiError, audit, policyJSON, readJson, requireSameOrigin, stringValue } from "@/lib/api";
import { requireUser } from "@/lib/auth";
import { actionPlanData, parseAndValidateItems, parseItems, planJSON } from "@/lib/action-plan";

export const runtime = "nodejs";

export async function GET(request: Request) {
  try {
    await requireUser(request);
    const policyId = new URL(request.url).searchParams.get("policyId");
    const rows = await db.actionPlan.findMany({
      where: policyId ? { policyId } : undefined,
      orderBy: { updatedAt: "desc" },
    });
    return NextResponse.json({ actionPlans: rows.map((row) => planJSON(row)) });
  } catch (error) {
    return apiError(error);
  }
}

export async function POST(request: Request) {
  try {
    requireSameOrigin(request);
    const user = await requireUser(request);
    const body = await readJson(request, 100_000);
    const policyId = stringValue(body.policyId, "Policy ID", 100, true);
    const policy = await db.policy.findUnique({ where: { id: policyId } });
    if (!policy) return NextResponse.json({ error: "Policy not found." }, { status: 404 });
    const existing = await db.actionPlan.findFirst({
      where: { policyId, status: "Draft" },
      orderBy: { updatedAt: "desc" },
    });
    if (existing) {
      const hasEdits = body.items !== undefined || body.noImmediateAction !== undefined;
      if (!hasEdits)
        return NextResponse.json({ actionPlan: planJSON(existing), existing: true });
      const noImmediateAction = body.noImmediateAction === true;
      const incoming = noImmediateAction
        ? []
        : parseAndValidateItems(body.items ?? [], policyJSON(policy));
      const current = noImmediateAction ? [] : parseItems(existing.itemsJson);
      const merged = new Map([...current, ...incoming].map((item) => [item.id, item]));
      const items = noImmediateAction
        ? []
        : parseAndValidateItems([...merged.values()], policyJSON(policy));
      const updated = await db.actionPlan.update({
        where: { id: existing.id },
        data: {
          itemsJson: JSON.stringify(items),
          noImmediateAction,
          ...(body.summary === undefined ? {} : { summary: stringValue(body.summary, "Action-plan summary", 4_000) }),
        },
      });
      return NextResponse.json({ actionPlan: planJSON(updated), existing: true });
    }
    const created = await db.$transaction(async (tx) => {
      const row = await tx.actionPlan.create({
        data: {
          policyId,
          ...actionPlanData(body, policyJSON(policy), user),
        },
      });
      await audit(tx, {
        actor: user.name,
        action: "Recommended action plan drafted",
        entityType: "ActionPlan",
        entityId: row.id,
        detail: "Generated from source-grounded analysis; staff approval is required before conversion to tasks.",
        after: row,
      });
      return row;
    });
    return NextResponse.json({ actionPlan: planJSON(created) }, { status: 201 });
  } catch (error) {
    return apiError(error);
  }
}
