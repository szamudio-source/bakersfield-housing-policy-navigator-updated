import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { apiError, audit, requireSameOrigin } from "@/lib/api";
import { requireUser } from "@/lib/auth";
import { parseItems, planJSON } from "@/lib/action-plan";

export const runtime = "nodejs";

export async function POST(
  request: Request,
  context: { params: Promise<{ id: string }> },
) {
  try {
    requireSameOrigin(request);
    const user = await requireUser(request);
    const { id } = await context.params;
    const plan = await db.actionPlan.findUnique({ where: { id } });
    if (!plan) return NextResponse.json({ error: "Action plan not found." }, { status: 404 });
    if (plan.status === "Draft")
      return NextResponse.json({ error: "A reviewer must approve the action plan first." }, { status: 400 });
    const items = plan.noImmediateAction ? [] : parseItems(plan.itemsJson);
    const result = await db.$transaction(async (tx) => {
      const created = [];
      for (const item of items) {
        const existing = await tx.task.findFirst({
          where: { actionPlanId: id, actionPlanItemId: item.id },
        });
        if (existing) {
          created.push(existing);
          continue;
        }
        const priority =
          item.urgency === "Urgent"
            ? "Urgent"
            : item.urgency === "High"
              ? "High"
              : item.urgency === "Low"
                ? "Low"
                : "Medium";
        const task = await tx.task.create({
          data: {
            title: item.title,
            description: item.rationale,
            department: item.department,
            assignee: item.assignee,
            dueDate: item.dueDate ? new Date(item.dueDate) : null,
            dateType: item.dueDate ? "AI suggested" : "Staff target",
            priority,
            status: "To do",
            notes: item.monitor
              ? "Monitor the policy for future official-source changes."
              : "",
            policyId: plan.policyId,
            actionPlanId: id,
            actionPlanItemId: item.id,
            createdById: user.id,
            sourceQuote: item.sourceQuote,
          },
        });
        created.push(task);
      }
      const updated = await tx.actionPlan.update({
        where: { id },
        data: { status: "Converted" },
      });
      await audit(tx, {
        actor: user.name,
        action: "Approved action plan converted to tasks",
        entityType: "ActionPlan",
        entityId: id,
        detail: `${created.length} task${created.length === 1 ? "" : "s"} linked to the original policy and action plan.`,
        before: plan,
        after: updated,
      });
      return { updated, created };
    });
    return NextResponse.json({
      actionPlan: planJSON(result.updated),
      tasks: result.created,
    });
  } catch (error) {
    return apiError(error);
  }
}
