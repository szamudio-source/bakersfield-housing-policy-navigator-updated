import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { apiError, audit, policyJSON, readJson, requireSameOrigin, stringValue } from "@/lib/api";
import { requireReviewer, requireUser } from "@/lib/auth";
import { parseAndValidateItems, planJSON } from "@/lib/action-plan";

export const runtime = "nodejs";

export async function PATCH(
  request: Request,
  context: { params: Promise<{ id: string }> },
) {
  try {
    requireSameOrigin(request);
    const user = await requireUser(request);
    const { id } = await context.params;
    const body = await readJson(request, 100_000);
    const before = await db.actionPlan.findUnique({ where: { id } });
    if (!before) throw new Error("Action plan not found.");
    const policy = await db.policy.findUnique({ where: { id: before.policyId } });
    if (!policy) throw new Error("Related policy not found.");
    if (before.status === "Converted")
      throw new Error("Converted action plans are read-only.");
    if (user.role === "STAFF" && before.createdById !== user.id)
      throw new Error("Staff may edit only action plans they created.");
    const approve = body.approve === true;
    if (approve) requireReviewer(user);
    const noImmediateAction = body.noImmediateAction === undefined
      ? before.noImmediateAction
      : body.noImmediateAction === true;
    const items = noImmediateAction
      ? []
      : parseAndValidateItems(
          body.items === undefined
            ? JSON.parse(before.itemsJson || "[]")
            : body.items,
          policyJSON(policy),
        );
    const data = {
      title: stringValue(body.title ?? before.title, "Action-plan title", 240, true),
      summary: stringValue(body.summary ?? before.summary, "Action-plan summary", 4_000),
      noImmediateAction,
      itemsJson: JSON.stringify(items),
      ...(approve
        ? { status: "Approved", approvedBy: user.name, approvedAt: new Date() }
        : {}),
    };
    const updated = await db.$transaction(async (tx) => {
      const row = await tx.actionPlan.update({ where: { id }, data });
      await audit(tx, {
        actor: user.name,
        action: approve ? "Recommended action plan approved" : "Recommended action plan edited",
        entityType: "ActionPlan",
        entityId: id,
        detail: approve
          ? "Reviewer approval recorded. The recommendations may now be converted into staff tasks."
          : "Draft recommendations edited; approval remains required.",
        before,
        after: row,
      });
      return row;
    });
    return NextResponse.json({ actionPlan: planJSON(updated) });
  } catch (error) {
    if (error instanceof Error && error.message === "Action plan not found.")
      return NextResponse.json({ error: error.message }, { status: 404 });
    if (error instanceof Error && error.message === "Related policy not found.")
      return NextResponse.json({ error: error.message }, { status: 404 });
    if (error instanceof Error && error.message.includes("may edit"))
      return NextResponse.json({ error: error.message }, { status: 403 });
    if (error instanceof Error && (error.message.includes("read-only") || error.message.includes("at least one")))
      return NextResponse.json({ error: error.message }, { status: 400 });
    return apiError(error);
  }
}
